#pragma once
#include<string>
using namespace std;


class Topic
{
	int id;
	string name;
};