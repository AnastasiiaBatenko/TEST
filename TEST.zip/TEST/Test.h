#pragma once
#include<string>
using namespace std;


class Test
{
	int id;
	int topic;
	string name;
};