#pragma once
#include<string>
using namespace std;

class Question
{
	int id;
	int testID;
	string question;
	string answer1;
	string answer2;
	string answer3;
	string answer4;
};
